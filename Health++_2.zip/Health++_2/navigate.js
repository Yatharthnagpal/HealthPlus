document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("openButtonsPage").addEventListener("click", function() {
        window.location.href = "buttons.html";
    });
});
